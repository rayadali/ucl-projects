public class Main
{
  public static void main(String[] args)
  {
    Input in = new Input();
    TODO todo = new TODO(in,System.out);
    todo.go();
  }
}
