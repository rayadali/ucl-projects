README Java TODOlist v1.0

Created by Rayad Ali, UCL


---
Requirements
---

Java 1.5+
Path Variables set up

----
Instructions
---

Extract java class  files to a folder.

Enter Command Prommpt and navigate to that folder.

Type "javac *.java" and then "java Main"

The program should then load.

Enter numbers as appropriate.

Remember to save files as ".txt"